package com.rentalinvoice.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.rentalinvoice.app.data.Format
import com.rentalinvoice.app.data.Invoice
import com.rentalinvoice.app.data.InvoiceItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvoiceEditScreen(
    initial: Invoice,
    isNew: Boolean,
    onBack: () -> Unit,
    onSave: (Invoice) -> Unit,
    onPdf: (Invoice) -> Unit,
) {
    var inv by remember { mutableStateOf(initial) }

    fun updateItem(index: Int, f: (InvoiceItem) -> InvoiceItem) {
        inv = inv.copy(items = inv.items.toMutableList().also { it[index] = f(it[index]) })
    }

    Scaffold(
        modifier = Modifier.imePadding(),
        topBar = {
            TopAppBar(
                title = { Text(if (isNew) "Invoice Baru" else "Edit Invoice") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                },
            )
        },
        bottomBar = {
            Surface(shadowElevation = 8.dp, tonalElevation = 2.dp) {
                Column(Modifier.navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("TOTAL", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(
                            Format.rupiah(inv.total),
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 8.dp)) {
                        OutlinedButton(onClick = { onSave(inv) }, modifier = Modifier.weight(1f)) { Text("Simpan") }
                        Button(onClick = { onPdf(inv) }, modifier = Modifier.weight(1f)) { Text("Buat PDF") }
                    }
                }
            }
        },
    ) { pad ->
        LazyColumn(
            contentPadding = PaddingValues(
                start = 16.dp, end = 16.dp,
                top = pad.calculateTopPadding() + 8.dp,
                bottom = pad.calculateBottomPadding() + 16.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                TextInput("Nomor invoice", inv.number, Modifier.fillMaxWidth(), caps = KeyboardCapitalization.Characters) {
                    inv = inv.copy(number = it)
                }
            }
            item {
                TextInput("Kostumer (mis. Bpk. DODI)", inv.customer, Modifier.fillMaxWidth(), caps = KeyboardCapitalization.Words) {
                    inv = inv.copy(customer = it)
                }
            }
            item {
                DateField("Tanggal invoice", inv.date, Modifier.fillMaxWidth()) { inv = inv.copy(date = it) }
            }
            item {
                Text("Rincian Rental", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            itemsIndexed(inv.items) { index, item ->
                ItemCard(
                    index = index,
                    item = item,
                    canDelete = inv.items.size > 1,
                    onChange = { f -> updateItem(index, f) },
                    onDelete = { inv = inv.copy(items = inv.items.filterIndexed { i, _ -> i != index }) },
                )
            }
            item {
                OutlinedButton(
                    onClick = {
                        // Armada baru mewarisi periode armada terakhir agar cepat diisi.
                        val last = inv.items.lastOrNull()
                        val newItem = if (last != null) {
                            InvoiceItem(startDate = last.startDate, endDate = last.endDate, durasi = last.durasi)
                        } else InvoiceItem()
                        inv = inv.copy(items = inv.items + newItem)
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Tambah Armada")
                }
            }
        }
    }
}

@Composable
private fun ItemCard(
    index: Int,
    item: InvoiceItem,
    canDelete: Boolean,
    onChange: ((InvoiceItem) -> InvoiceItem) -> Unit,
    onDelete: () -> Unit,
) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Armada #${index + 1}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (canDelete) {
                    IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Hapus armada") }
                }
            }
            TextInput("Armada (mis. Toyota Alphard)", item.armada, Modifier.fillMaxWidth(), caps = KeyboardCapitalization.Words) { v ->
                onChange { it.copy(armada = v) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DateField("Mulai", item.startDate, Modifier.weight(1f)) { d ->
                    onChange {
                        val end = if (it.endDate.isBefore(d)) d else it.endDate
                        it.copy(startDate = d, endDate = end, durasi = InvoiceItem.daysBetween(d, end))
                    }
                }
                DateField("Selesai", item.endDate, Modifier.weight(1f)) { d ->
                    onChange {
                        val start = if (d.isBefore(it.startDate)) d else it.startDate
                        it.copy(startDate = start, endDate = d, durasi = InvoiceItem.daysBetween(start, d))
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField("Unit", item.unit.toLong(), Modifier.weight(1f)) { v ->
                    onChange { it.copy(unit = v.coerceAtMost(9999).toInt()) }
                }
                NumberField("Durasi (hari)", item.durasi.toLong(), Modifier.weight(1f), supporting = "Otomatis dari tanggal") { v ->
                    onChange { it.copy(durasi = v.coerceAtMost(9999).toInt()) }
                }
            }
            NumberField(
                "Tarif / hari / unit (Rp)", item.tarif, Modifier.fillMaxWidth(),
                supporting = if (item.tarif > 0) Format.rupiah(item.tarif) else null,
            ) { v -> onChange { it.copy(tarif = v) } }
            Text(
                "${item.unit} unit × ${item.durasi} hari × ${Format.rupiah(item.tarif)} = ${Format.rupiah(item.subtotal)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
