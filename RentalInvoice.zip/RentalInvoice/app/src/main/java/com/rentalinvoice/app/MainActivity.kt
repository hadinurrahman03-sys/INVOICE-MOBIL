package com.rentalinvoice.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.rentalinvoice.app.data.Invoice
import com.rentalinvoice.app.data.Repository
import com.rentalinvoice.app.pdf.InvoicePdf
import com.rentalinvoice.app.ui.AppTheme
import com.rentalinvoice.app.ui.InvoiceEditScreen
import com.rentalinvoice.app.ui.InvoiceListScreen
import com.rentalinvoice.app.ui.PreviewScreen
import com.rentalinvoice.app.ui.SettingsScreen
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo = Repository(applicationContext)
        setContent { AppTheme { App(repo) } }
    }
}

private sealed interface Screen {
    data object List : Screen
    data class Edit(val invoice: Invoice, val isNew: Boolean) : Screen
    data class Preview(val file: File, val title: String, val stamp: Long) : Screen
    data object Settings : Screen
}

@Composable
private fun App(repo: Repository) {
    val ctx = LocalContext.current
    var stack by remember { mutableStateOf(listOf<Screen>(Screen.List)) }
    var invoices by remember { mutableStateOf(repo.loadInvoices()) }

    fun push(s: Screen) { stack = stack + s }
    fun pop() { if (stack.size > 1) stack = stack.dropLast(1) }
    fun refresh() { invoices = repo.loadInvoices() }

    BackHandler(enabled = stack.size > 1) { pop() }

    when (val screen = stack.last()) {
        Screen.List -> InvoiceListScreen(
            invoices = invoices,
            onNew = { push(Screen.Edit(repo.newInvoice(), isNew = true)) },
            onOpen = { push(Screen.Edit(it, isNew = false)) },
            onDelete = { repo.deleteInvoice(it.id); refresh() },
            onSettings = { push(Screen.Settings) },
        )

        is Screen.Edit -> InvoiceEditScreen(
            initial = screen.invoice,
            isNew = screen.isNew,
            onBack = { pop() },
            onSave = { inv ->
                repo.saveInvoice(inv)
                refresh()
                Toast.makeText(ctx, "Invoice disimpan", Toast.LENGTH_SHORT).show()
                pop()
            },
            onPdf = { inv ->
                val problem = validate(inv)
                if (problem != null) {
                    Toast.makeText(ctx, problem, Toast.LENGTH_LONG).show()
                } else {
                    try {
                        repo.saveInvoice(inv)
                        refresh()
                        val file = repo.pdfFile(inv)
                        InvoicePdf.generate(repo.loadProfile(), inv, repo.loadPdfImages(), file)
                        // Ganti layar edit dengan versi tersimpan, lalu buka pratinjau.
                        stack = stack.dropLast(1) + Screen.Edit(inv, isNew = false) +
                            Screen.Preview(file, inv.number, System.currentTimeMillis())
                    } catch (e: Exception) {
                        Toast.makeText(ctx, "Gagal membuat PDF: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            },
        )

        is Screen.Preview -> PreviewScreen(file = screen.file, title = screen.title, onBack = { pop() })

        Screen.Settings -> SettingsScreen(repo = repo, onBack = { pop() })
    }
}

private fun validate(inv: Invoice): String? = when {
    inv.number.isBlank() -> "Nomor invoice belum diisi"
    inv.customer.isBlank() -> "Nama kostumer belum diisi"
    inv.items.isEmpty() -> "Tambahkan minimal satu armada"
    inv.items.any { it.armada.isBlank() } -> "Nama armada belum diisi"
    inv.items.any { it.unit <= 0 || it.durasi <= 0 } -> "Unit dan durasi harus lebih dari 0"
    inv.items.any { it.tarif <= 0 } -> "Tarif armada belum diisi"
    else -> null
}
