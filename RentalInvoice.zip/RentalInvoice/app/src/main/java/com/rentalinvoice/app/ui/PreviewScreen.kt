package com.rentalinvoice.app.ui

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.rentalinvoice.app.pdf.PdfActions
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PreviewScreen(file: File, title: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    // lastModified sebagai kunci agar pratinjau diperbarui jika PDF dibuat ulang.
    val pages = remember(file.absolutePath, file.lastModified()) {
        runCatching { PdfActions.render(file) }.getOrDefault(emptyList())
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali") }
                },
                actions = {
                    IconButton(onClick = { PdfActions.share(ctx, file) }) {
                        Icon(Icons.Filled.Share, contentDescription = "Bagikan")
                    }
                },
            )
        },
        bottomBar = {
            Surface(shadowElevation = 8.dp) {
                Row(
                    Modifier.navigationBarsPadding().padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    OutlinedButton(
                        onClick = {
                            val msg = runCatching { "Tersimpan di ${PdfActions.saveToDownloads(ctx, file)}" }
                                .getOrElse { "Gagal menyimpan: ${it.message}" }
                            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                        },
                        modifier = Modifier.weight(1f),
                    ) { Text("Simpan ke HP") }
                    Button(onClick = { PdfActions.share(ctx, file) }, modifier = Modifier.weight(1f)) {
                        Text("Bagikan / WA")
                    }
                }
            }
        },
    ) { pad ->
        Box(Modifier.fillMaxSize().background(Color(0xFFE0E0E0))) {
            if (pages.isEmpty()) {
                Text("Pratinjau tidak tersedia", Modifier.align(Alignment.Center))
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(
                        start = 12.dp, end = 12.dp,
                        top = pad.calculateTopPadding() + 12.dp,
                        bottom = pad.calculateBottomPadding() + 12.dp,
                    ),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(pages) { bmp ->
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "Halaman invoice",
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(bmp.width.toFloat() / bmp.height)
                                .shadow(4.dp)
                                .background(Color.White),
                        )
                    }
                }
            }
        }
    }
}
