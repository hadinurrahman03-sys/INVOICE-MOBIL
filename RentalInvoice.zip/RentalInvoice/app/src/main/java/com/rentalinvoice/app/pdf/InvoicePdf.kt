package com.rentalinvoice.app.pdf

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.rentalinvoice.app.data.CompanyProfile
import com.rentalinvoice.app.data.Format
import com.rentalinvoice.app.data.Invoice
import com.rentalinvoice.app.data.PdfImages
import java.io.File
import java.io.FileOutputStream

/**
 * Menggambar invoice ke PDF ukuran A4 (595 x 842 pt) dengan tata letak
 * yang meniru contoh invoice UD. Amanda Wisata.
 */
object InvoicePdf {
    private const val PAGE_W = 595
    private const val PAGE_H = 842

    private val BLUE = Color.rgb(11, 77, 181)
    private val DARK_RED = Color.rgb(139, 28, 35)
    private val HEADER_BG = Color.rgb(79, 129, 189)
    private val ROW_BG = Color.rgb(219, 229, 241)

    /** Batas kolom tabel (x dalam pt). */
    private val COLS = floatArrayOf(36f, 81f, 186f, 232f, 336f, 400f, 485f, 567f)
    private val HEADERS = arrayOf("No.", "Armada", "Unit", "Periode / Tanggal", "Durasi", "Tarif / Hari", "Subtotal")

    private const val HEADER_H = 18f
    private const val MIN_ROW_H = 26f

    /** Tinggi bagian bawah (total s.d. ucapan terima kasih), diukur dari bawah tabel. */
    private const val BOTTOM_BLOCK_H = 400f

    private fun paint(
        size: Float,
        color: Int = Color.BLACK,
        bold: Boolean = false,
        align: Paint.Align = Paint.Align.LEFT,
        spacing: Float = 0f,
    ) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size
        this.color = color
        typeface = Typeface.create(Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
        textAlign = align
        letterSpacing = spacing
    }

    /** Perkecil ukuran huruf sampai teks muat di lebar maxW. */
    private fun TextPaint.fit(text: String, maxW: Float): TextPaint {
        while (measureText(text) > maxW && textSize > 6f) textSize -= 0.5f
        return this
    }

    fun generate(profile: CompanyProfile, invoice: Invoice, images: PdfImages, out: File) {
        val doc = PdfDocument()
        try {
            var pageNo = 1
            var page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
            var c = page.canvas

            val tableTop = drawHeader(c, profile, invoice, images)
            var y = drawTableHeader(c, tableTop)

            val cellPaint = paint(9f, bold = true)
            for ((i, item) in invoice.items.withIndex()) {
                val cells = arrayOf(
                    "${i + 1}",
                    item.armada,
                    "${item.unit}",
                    Format.periode(item.startDate, item.endDate),
                    "${item.durasi} Hari",
                    "${Format.rupiah(item.tarif)}\n/unit",
                    Format.rupiah(item.subtotal),
                )
                val layouts = cells.mapIndexed { ci, text ->
                    cellLayout(text, COLS[ci + 1] - COLS[ci] - 6f, cellPaint)
                }
                val rowH = maxOf(MIN_ROW_H, layouts.maxOf { it.height }.toFloat() + 8f)

                if (y + rowH > PAGE_H - 50f) {
                    doc.finishPage(page)
                    pageNo++
                    page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
                    c = page.canvas
                    y = drawTableHeader(c, 50f)
                }
                drawRow(c, y, rowH, layouts)
                y += rowH
            }

            if (y + BOTTOM_BLOCK_H > PAGE_H - 20f) {
                doc.finishPage(page)
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
                c = page.canvas
                y = 20f
            }
            drawBottom(c, y, profile, invoice, images)
            doc.finishPage(page)

            out.parentFile?.mkdirs()
            FileOutputStream(out).use { doc.writeTo(it) }
        } finally {
            doc.close()
        }
    }

    // ------------------------------------------------------------------ Kop

    /** Menggambar kop, nomor, kostumer. Mengembalikan posisi y awal tabel. */
    private fun drawHeader(c: Canvas, p: CompanyProfile, inv: Invoice, img: PdfImages): Float {
        // Judul INVOICE
        c.drawText("INVOICE", 60f, 122f, paint(46f, BLUE, bold = true))

        // Logo kanan atas: gambar pilihan pengguna, atau siluet mobil bawaan
        if (img.logo != null) {
            drawBitmapFit(c, img.logo, RectF(347f, 30f, 549f, 86f))
        } else {
            drawCarSwoosh(c)
        }

        // Nama usaha & keterangan
        c.drawText(p.name, 348f, 104f, paint(19f, bold = true).fit(p.name, 201f))
        c.drawText(p.subtitle, 350f, 124f, paint(16f).fit(p.subtitle, 199f))

        // Baris kontak merah + garis
        c.drawText(p.contactLine, 60f, 148f, paint(10.5f, DARK_RED, bold = true, spacing = 0.06f).fit(p.contactLine, 489f))
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; strokeWidth = 0.8f }
        c.drawLine(60f, 155f, 549f, 155f, line)

        // Nomor & kostumer
        val label = paint(13f, bold = true)
        c.drawText("Nomor", 60f, 178f, label)
        c.drawText(": ${inv.number}", 132f, 178f, label)
        c.drawText("Kostumer", 60f, 199f, label)
        c.drawText(": ${inv.customer}", 132f, 199f, paint(13f, bold = true).fit(": ${inv.customer}", 415f))

        c.drawText("Rincian Rental :", 60f, 244f, paint(12f, bold = true))
        return 262f
    }

    /** Siluet mobil sederhana (hitam + merah) seperti di contoh, dipakai bila logo belum diatur. */
    private fun drawCarSwoosh(c: Canvas) {
        val black = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.FILL }
        val roof = Path().apply {
            moveTo(347f, 80f)
            cubicTo(385f, 72f, 405f, 54f, 452f, 53f)
            cubicTo(502f, 52f, 534f, 62f, 549f, 74f)
            lineTo(546f, 77f)
            cubicTo(530f, 67f, 497f, 59f, 453f, 60f)
            cubicTo(412f, 61f, 388f, 75f, 350f, 83f)
            close()
        }
        c.drawPath(roof, black)
        val red = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(178, 34, 52); style = Paint.Style.STROKE; strokeWidth = 2.2f; strokeCap = Paint.Cap.ROUND
        }
        val stripe = Path().apply {
            moveTo(372f, 81f)
            cubicTo(430f, 71f, 500f, 70f, 540f, 79f)
        }
        c.drawPath(stripe, red)
        val base = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; strokeWidth = 2.2f; strokeCap = Paint.Cap.ROUND }
        c.drawLine(352f, 86f, 520f, 86f, base)
    }

    // ---------------------------------------------------------------- Tabel

    private fun drawTableHeader(c: Canvas, top: Float): Float {
        val bg = Paint().apply { color = HEADER_BG; style = Paint.Style.FILL }
        c.drawRect(COLS.first(), top, COLS.last(), top + HEADER_H, bg)
        val sep = Paint().apply { color = Color.WHITE; strokeWidth = 0.6f }
        val text = paint(9f, Color.WHITE, bold = true, align = Paint.Align.CENTER)
        for (i in HEADERS.indices) {
            val cx = (COLS[i] + COLS[i + 1]) / 2f
            c.drawText(HEADERS[i], cx, top + 12.5f, text)
            if (i > 0) c.drawLine(COLS[i], top, COLS[i], top + HEADER_H, sep)
        }
        return top + HEADER_H
    }

    private fun cellLayout(text: String, width: Float, p: TextPaint): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width.toInt().coerceAtLeast(10))
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .build()

    private fun drawRow(c: Canvas, top: Float, h: Float, layouts: List<StaticLayout>) {
        val bg = Paint().apply { color = ROW_BG; style = Paint.Style.FILL }
        c.drawRect(COLS.first(), top, COLS.last(), top + h, bg)
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 0.7f }
        for (i in layouts.indices) {
            c.drawRect(COLS[i], top, COLS[i + 1], top + h, border)
            val l = layouts[i]
            c.save()
            c.translate(COLS[i] + 3f, top + (h - l.height) / 2f)
            l.draw(c)
            c.restore()
        }
    }

    // ---------------------------------------------------------- Bagian bawah

    private fun drawBottom(c: Canvas, top: Float, p: CompanyProfile, inv: Invoice, img: PdfImages) {
        // TOTAL
        c.drawText(
            "TOTAL : ${Format.rupiah(inv.total)}", 542f, top + 60f,
            paint(16f, bold = true, align = Paint.Align.RIGHT),
        )

        // Pembayaran
        val normal = paint(13f)
        c.drawText("PEMBAYARAN :", 30f, top + 152f, normal)
        c.drawText("Nama", 30f, top + 178f, normal)
        c.drawText(":  ${p.payeeName}", 76f, top + 178f, normal)
        c.drawText("No Rek :", 30f, top + 199f, normal)
        val accounts = p.bankAccounts.lines().map { it.trim() }.filter { it.isNotEmpty() }
        accounts.forEachIndexed { i, acc ->
            c.drawText(acc, 89f, top + 199f + i * 18f, paint(13f).fit(acc, 250f))
        }

        // Tempat, tanggal & tanda tangan
        val center = paint(13f, align = Paint.Align.CENTER)
        c.drawText("${p.city}, ${Format.tanggalPanjang(inv.date)}", 463f, top + 225f, center)
        img.stamp?.let { drawBitmapFit(c, it, RectF(372f, top + 235f, 512f, top + 282f)) }
        c.drawText(p.signerName, 450f, top + 339f, center)
        img.signature?.let { drawBitmapFit(c, it, RectF(357f, top + 232f, 532f, top + 351f)) }

        // Ucapan terima kasih
        c.drawText(
            p.thanks, PAGE_W / 2f, top + 394f,
            paint(10f, BLUE, bold = true, align = Paint.Align.CENTER, spacing = 0.08f).fit(p.thanks, 540f),
        )
    }

    /** Gambar bitmap di tengah kotak, menjaga rasio. */
    private fun drawBitmapFit(c: Canvas, bmp: Bitmap, box: RectF) {
        val scale = minOf(box.width() / bmp.width, box.height() / bmp.height)
        val w = bmp.width * scale
        val h = bmp.height * scale
        val left = box.left + (box.width() - w) / 2f
        val topY = box.top + (box.height() - h) / 2f
        c.drawBitmap(bmp, null, RectF(left, topY, left + w, topY + h), Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
    }
}
