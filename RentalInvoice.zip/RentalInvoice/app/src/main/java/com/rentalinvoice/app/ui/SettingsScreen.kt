package com.rentalinvoice.app.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.rentalinvoice.app.data.CompanyProfile
import com.rentalinvoice.app.data.ImageKind
import com.rentalinvoice.app.data.Repository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(repo: Repository, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var p by remember { mutableStateOf(repo.loadProfile()) }
    var imageVersion by remember { mutableIntStateOf(0) }
    var pendingKind by remember { mutableStateOf(ImageKind.LOGO) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val ok = repo.importImage(uri, pendingKind)
            if (!ok) Toast.makeText(ctx, "Gambar gagal dibaca", Toast.LENGTH_SHORT).show()
            imageVersion++
        }
    }

    fun save() {
        repo.saveProfile(p)
        Toast.makeText(ctx, "Pengaturan disimpan", Toast.LENGTH_SHORT).show()
        onBack()
    }

    Scaffold(
        modifier = Modifier.imePadding(),
        topBar = {
            TopAppBar(
                title = { Text("Pengaturan Usaha") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali") }
                },
                actions = {
                    IconButton(onClick = { save() }) { Icon(Icons.Filled.Check, contentDescription = "Simpan") }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Section("Kop invoice")
            TextInput("Nama usaha", p.name, Modifier.fillMaxWidth(), caps = KeyboardCapitalization.Characters) { p = p.copy(name = it) }
            TextInput("Keterangan (di bawah nama)", p.subtitle, Modifier.fillMaxWidth()) { p = p.copy(subtitle = it) }
            TextInput("Baris telepon & alamat", p.contactLine, Modifier.fillMaxWidth(), singleLine = false) { p = p.copy(contactLine = it) }
            TextInput("Awalan nomor invoice (mis. INV/AW)", p.numberPrefix, Modifier.fillMaxWidth(), caps = KeyboardCapitalization.Characters) {
                p = p.copy(numberPrefix = it)
            }

            Section("Pembayaran")
            TextInput("Nama pemilik rekening", p.payeeName, Modifier.fillMaxWidth(), caps = KeyboardCapitalization.Characters) { p = p.copy(payeeName = it) }
            TextInput("No. rekening (satu baris per bank)", p.bankAccounts, Modifier.fillMaxWidth(), singleLine = false, minLines = 3) {
                p = p.copy(bankAccounts = it)
            }

            Section("Tanda tangan")
            TextInput("Kota (untuk tanggal)", p.city, Modifier.fillMaxWidth(), caps = KeyboardCapitalization.Words) { p = p.copy(city = it) }
            TextInput("Nama penanda tangan", p.signerName, Modifier.fillMaxWidth(), caps = KeyboardCapitalization.Characters) { p = p.copy(signerName = it) }
            TextInput("Ucapan di bagian bawah", p.thanks, Modifier.fillMaxWidth(), singleLine = false, caps = KeyboardCapitalization.Characters) {
                p = p.copy(thanks = it)
            }

            Section("Gambar")
            Text(
                "Gunakan gambar PNG berlatar transparan agar stempel & tanda tangan menyatu dengan kertas. " +
                    "Jika logo kop kosong, aplikasi memakai siluet mobil bawaan.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            ImageKind.entries.forEach { kind ->
                ImagePickerRow(
                    repo = repo,
                    kind = kind,
                    version = imageVersion,
                    onPick = { pendingKind = kind; picker.launch("image/*") },
                    onRemove = { repo.removeImage(kind); imageVersion++ },
                )
            }

            TextButton(onClick = { p = CompanyProfile() }) { Text("Kembalikan teks ke contoh awal") }
            Button(onClick = { save() }, modifier = Modifier.fillMaxWidth()) { Text("Simpan Pengaturan") }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 8.dp),
    )
}

@Composable
private fun ImagePickerRow(repo: Repository, kind: ImageKind, version: Int, onPick: () -> Unit, onRemove: () -> Unit) {
    val bmp = remember(kind, version) { repo.loadImage(kind)?.asImageBitmap() }
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(width = 110.dp, height = 64.dp).background(Color.White),
                contentAlignment = Alignment.Center,
            ) {
                if (bmp != null) {
                    Image(bmp, contentDescription = kind.label, contentScale = ContentScale.Fit, modifier = Modifier.padding(4.dp))
                } else {
                    Text("Belum ada", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(kind.label, fontWeight = FontWeight.Medium)
                Row {
                    TextButton(onClick = onPick) { Text(if (bmp == null) "Pilih" else "Ganti") }
                    if (bmp != null) TextButton(onClick = onRemove) { Text("Hapus") }
                }
            }
        }
    }
}
