package com.rentalinvoice.app.data

import java.time.LocalDate

object Format {
    private val BULAN = arrayOf(
        "Januari", "Februari", "Maret", "April", "Mei", "Juni",
        "Juli", "Agustus", "September", "Oktober", "November", "Desember",
    )
    private val BULAN_PENDEK = arrayOf(
        "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
        "Jul", "Agu", "Sep", "Okt", "Nov", "Des",
    )
    private val ROMAWI = arrayOf("I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII")

    /** 2900000 -> "2.900.000" */
    fun ribuan(v: Long): String {
        val s = kotlin.math.abs(v).toString()
        val sb = StringBuilder()
        s.forEachIndexed { i, ch ->
            if (i > 0 && (s.length - i) % 3 == 0) sb.append('.')
            sb.append(ch)
        }
        return (if (v < 0) "-" else "") + sb.toString()
    }

    /** 2900000 -> "Rp2.900.000,-" */
    fun rupiah(v: Long): String = "Rp${ribuan(v)},-"

    /** 6 Oktober 2026 */
    fun tanggalPanjang(d: LocalDate): String = "${d.dayOfMonth} ${BULAN[d.monthValue - 1]} ${d.year}"

    /** 6 Okt 2026 */
    fun tanggalPendek(d: LocalDate): String = "${d.dayOfMonth} ${BULAN_PENDEK[d.monthValue - 1]} ${d.year}"

    /** "6 s.d 11 Okt 2026", "28 Sep s.d 3 Okt 2026", atau "6 Okt 2026" bila satu hari. */
    fun periode(a: LocalDate, b: LocalDate): String {
        if (a == b) return tanggalPendek(a)
        return when {
            a.year == b.year && a.monthValue == b.monthValue ->
                "${a.dayOfMonth} s.d ${b.dayOfMonth} ${BULAN_PENDEK[b.monthValue - 1]} ${b.year}"
            a.year == b.year ->
                "${a.dayOfMonth} ${BULAN_PENDEK[a.monthValue - 1]} s.d ${tanggalPendek(b)}"
            else -> "${tanggalPendek(a)} s.d ${tanggalPendek(b)}"
        }
    }

    fun romawi(month: Int): String = ROMAWI[month - 1]

    /** Nama file aman, mis. "INV-AW-02-X-2026_DODI.pdf" */
    fun fileName(inv: Invoice): String {
        val base = "${inv.number}_${inv.customer}".ifBlank { "invoice" }
        val safe = base.replace(Regex("[^A-Za-z0-9._-]+"), "-").trim('-').take(80)
        return "${safe.ifBlank { "invoice" }}.pdf"
    }
}
