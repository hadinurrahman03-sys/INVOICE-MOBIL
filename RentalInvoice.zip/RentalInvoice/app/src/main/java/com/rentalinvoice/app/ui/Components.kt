package com.rentalinvoice.app.ui

import android.app.DatePickerDialog
import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import com.rentalinvoice.app.data.Format
import java.time.LocalDate

val BrandBlue = Color(0xFF0B4DB5)
val BrandRed = Color(0xFF8B1C23)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = androidx.compose.material3.lightColorScheme(
            primary = BrandBlue,
            secondary = BrandRed,
        ),
        content = content,
    )
}

fun showDatePicker(ctx: Context, initial: LocalDate, onPick: (LocalDate) -> Unit) {
    DatePickerDialog(
        ctx,
        { _, y, m, d -> onPick(LocalDate.of(y, m + 1, d)) },
        initial.year, initial.monthValue - 1, initial.dayOfMonth,
    ).show()
}

/** Kolom tanggal; ketuk untuk membuka kalender. */
@Composable
fun DateField(label: String, date: LocalDate, modifier: Modifier = Modifier, onPick: (LocalDate) -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    OutlinedTextField(
        value = Format.tanggalPendek(date),
        onValueChange = {},
        label = { Text(label) },
        readOnly = true,
        enabled = false,
        singleLine = true,
        trailingIcon = { Icon(Icons.Filled.DateRange, contentDescription = null) },
        colors = OutlinedTextFieldDefaults.colors(
            disabledTextColor = cs.onSurface,
            disabledBorderColor = cs.outline,
            disabledLabelColor = cs.onSurfaceVariant,
            disabledTrailingIconColor = cs.onSurfaceVariant,
        ),
        modifier = modifier.clickable { showDatePicker(ctx, date, onPick) },
    )
}

/** Kolom angka (hanya digit). Nilai 0 ditampilkan kosong. */
@Composable
fun NumberField(
    label: String,
    value: Long,
    modifier: Modifier = Modifier,
    supporting: String? = null,
    onChange: (Long) -> Unit,
) {
    OutlinedTextField(
        value = if (value == 0L) "" else value.toString(),
        onValueChange = { s -> onChange(s.filter { it.isDigit() }.take(12).toLongOrNull() ?: 0L) },
        label = { Text(label) },
        singleLine = true,
        supportingText = supporting?.let { { Text(it) } },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier,
    )
}

@Composable
fun TextInput(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    minLines: Int = 1,
    caps: KeyboardCapitalization = KeyboardCapitalization.Sentences,
    onChange: (String) -> Unit,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        minLines = minLines,
        keyboardOptions = KeyboardOptions(capitalization = caps),
        modifier = modifier,
    )
}
