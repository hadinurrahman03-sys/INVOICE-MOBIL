package com.rentalinvoice.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.rentalinvoice.app.R
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate

/** Jenis gambar yang bisa diatur di Pengaturan. */
enum class ImageKind(val fileName: String, val label: String) {
    LOGO("logo.png", "Logo kop (kanan atas)"),
    STAMP("stamp.png", "Stempel"),
    SIGNATURE("signature.png", "Tanda tangan"),
}

data class PdfImages(val logo: Bitmap?, val stamp: Bitmap?, val signature: Bitmap?)

/** Penyimpanan lokal sederhana (SharedPreferences + file gambar di memori internal). */
class Repository(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("rental_invoice", Context.MODE_PRIVATE)

    init {
        if (!prefs.getBoolean("initialized", false)) {
            // Stempel bawaan diambil dari contoh invoice; bisa diganti/dihapus di Pengaturan.
            runCatching {
                ctx.resources.openRawResource(R.drawable.default_stamp).use { input ->
                    FileOutputStream(imageFile(ImageKind.STAMP)).use { input.copyTo(it) }
                }
            }
            prefs.edit().putBoolean("initialized", true).apply()
        }
    }

    // ---------- Profil usaha ----------
    fun loadProfile(): CompanyProfile =
        prefs.getString("profile", null)
            ?.let { runCatching { CompanyProfile.fromJson(JSONObject(it)) }.getOrNull() }
            ?: CompanyProfile()

    fun saveProfile(p: CompanyProfile) {
        prefs.edit().putString("profile", p.toJson().toString()).apply()
    }

    // ---------- Invoice ----------
    fun loadInvoices(): List<Invoice> {
        val raw = prefs.getString("invoices", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { Invoice.fromJson(arr.getJSONObject(it)) }
        }.getOrDefault(emptyList()).sortedByDescending { it.createdAt }
    }

    fun exists(id: String): Boolean = loadInvoices().any { it.id == id }

    fun saveInvoice(inv: Invoice) {
        val list = loadInvoices().toMutableList()
        val idx = list.indexOfFirst { it.id == inv.id }
        if (idx >= 0) {
            list[idx] = inv
        } else {
            list.add(inv)
            // Invoice baru: naikkan nomor urut tahun tersebut.
            val key = "seq_${inv.date.year}"
            prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply()
        }
        writeInvoices(list)
    }

    fun deleteInvoice(id: String) = writeInvoices(loadInvoices().filterNot { it.id == id })

    private fun writeInvoices(list: List<Invoice>) {
        val arr = JSONArray().apply { list.forEach { put(it.toJson()) } }
        prefs.edit().putString("invoices", arr.toString()).apply()
    }

    /** Nomor berikutnya, format: INV/AW-02/X/2026 */
    fun nextNumber(date: LocalDate, prefix: String): String {
        val seq = prefs.getInt("seq_${date.year}", 0) + 1
        return "$prefix-${seq.toString().padStart(2, '0')}/${Format.romawi(date.monthValue)}/${date.year}"
    }

    fun newInvoice(): Invoice {
        val today = LocalDate.now()
        return Invoice(
            number = nextNumber(today, loadProfile().numberPrefix),
            date = today,
            items = listOf(InvoiceItem(startDate = today, endDate = today)),
        )
    }

    // ---------- Gambar ----------
    fun imageFile(kind: ImageKind) = File(ctx.filesDir, kind.fileName)

    fun importImage(uri: Uri, kind: ImageKind): Boolean {
        return try {
            val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                ?: return false
            val max = 900f
            val scale = minOf(1f, max / maxOf(src.width, src.height))
            val bmp = if (scale < 1f) {
                Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
            } else src
            FileOutputStream(imageFile(kind)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun removeImage(kind: ImageKind) {
        imageFile(kind).delete()
    }

    fun loadImage(kind: ImageKind): Bitmap? =
        imageFile(kind).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath) }

    fun loadPdfImages() = PdfImages(
        logo = loadImage(ImageKind.LOGO),
        stamp = loadImage(ImageKind.STAMP),
        signature = loadImage(ImageKind.SIGNATURE),
    )

    fun pdfFile(inv: Invoice): File = File(File(ctx.cacheDir, "invoices"), Format.fileName(inv))
}
