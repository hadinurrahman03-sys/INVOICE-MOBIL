package com.rentalinvoice.app.pdf

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File

object PdfActions {
    private fun uriFor(ctx: Context, file: File) =
        FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)

    /** Bagikan PDF (WhatsApp, email, Drive, dll). */
    fun share(ctx: Context, file: File) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uriFor(ctx, file))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Bagikan invoice"))
    }

    /** Buka dengan aplikasi PDF lain. */
    fun open(ctx: Context, file: File) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uriFor(ctx, file), "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Buka dengan"))
    }

    /** Simpan salinan ke folder Download/Invoice Rental. Mengembalikan lokasi file. */
    fun saveToDownloads(ctx: Context, file: File): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Invoice Rental")
            }
            val resolver = ctx.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Tidak bisa membuat file di Download")
            resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                ?: throw IllegalStateException("Tidak bisa menulis file")
            "Download/Invoice Rental/${file.name}"
        } else {
            val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
                ?: throw IllegalStateException("Penyimpanan tidak tersedia")
            val dest = File(dir, file.name)
            file.copyTo(dest, overwrite = true)
            dest.absolutePath
        }
    }

    /** Render setiap halaman PDF menjadi bitmap untuk pratinjau di aplikasi. */
    fun render(file: File, widthPx: Int = 1240): List<Bitmap> {
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        val renderer = PdfRenderer(pfd)
        try {
            return (0 until renderer.pageCount).map { i ->
                val page = renderer.openPage(i)
                try {
                    val h = widthPx * page.height / page.width
                    val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bmp
                } finally {
                    page.close()
                }
            }
        } finally {
            renderer.close()
            pfd.close()
        }
    }
}
