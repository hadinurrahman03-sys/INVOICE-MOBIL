package com.rentalinvoice.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.UUID

/** Satu baris armada pada invoice. Subtotal = tarif x unit x durasi. */
data class InvoiceItem(
    val armada: String = "",
    val unit: Int = 1,
    val startDate: LocalDate = LocalDate.now(),
    val endDate: LocalDate = LocalDate.now(),
    val durasi: Int = 1,
    val tarif: Long = 0L,
) {
    val subtotal: Long get() = tarif * unit * durasi

    fun toJson(): JSONObject = JSONObject().apply {
        put("armada", armada)
        put("unit", unit)
        put("start", startDate.toString())
        put("end", endDate.toString())
        put("durasi", durasi)
        put("tarif", tarif)
    }

    companion object {
        /** Jumlah hari inklusif: 6 s.d 11 = 6 hari. */
        fun daysBetween(start: LocalDate, end: LocalDate): Int =
            (ChronoUnit.DAYS.between(start, end).toInt() + 1).coerceAtLeast(1)

        fun fromJson(o: JSONObject) = InvoiceItem(
            armada = o.optString("armada"),
            unit = o.optInt("unit", 1),
            startDate = LocalDate.parse(o.getString("start")),
            endDate = LocalDate.parse(o.getString("end")),
            durasi = o.optInt("durasi", 1),
            tarif = o.optLong("tarif", 0L),
        )
    }
}

data class Invoice(
    val id: String = UUID.randomUUID().toString(),
    val number: String = "",
    val customer: String = "",
    val date: LocalDate = LocalDate.now(),
    val items: List<InvoiceItem> = listOf(InvoiceItem()),
    val createdAt: Long = System.currentTimeMillis(),
) {
    val total: Long get() = items.sumOf { it.subtotal }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("number", number)
        put("customer", customer)
        put("date", date.toString())
        put("createdAt", createdAt)
        put("items", JSONArray().apply { items.forEach { put(it.toJson()) } })
    }

    companion object {
        fun fromJson(o: JSONObject): Invoice {
            val arr = o.optJSONArray("items") ?: JSONArray()
            val list = (0 until arr.length()).map { InvoiceItem.fromJson(arr.getJSONObject(it)) }
            return Invoice(
                id = o.getString("id"),
                number = o.optString("number"),
                customer = o.optString("customer"),
                date = LocalDate.parse(o.getString("date")),
                items = list,
                createdAt = o.optLong("createdAt", System.currentTimeMillis()),
            )
        }
    }
}

/** Data usaha yang tampil di kop dan bagian bawah invoice. */
data class CompanyProfile(
    val name: String = "UD. AMANDA WISATA",
    val subtitle: String = "Rentcar",
    val contactLine: String = "Telepon: 08114117774 / 08124287213 Jln Minasa Upa No 79 Makassar",
    val city: String = "Makassar",
    val payeeName: String = "HAMDANI",
    val bankAccounts: String = "0083018418 (BCA)\n1520016661999 (Mandiri)\n034301054879502 (BRI)",
    val signerName: String = "HAMDANI",
    val thanks: String = "TERIMAKASIH TELAH MEMPERCAYAKAN UD.AMANDA RENTCAR UNTUK KEBUTUHAN RENTAL ANDA",
    val numberPrefix: String = "INV/AW",
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("name", name)
        put("subtitle", subtitle)
        put("contactLine", contactLine)
        put("city", city)
        put("payeeName", payeeName)
        put("bankAccounts", bankAccounts)
        put("signerName", signerName)
        put("thanks", thanks)
        put("numberPrefix", numberPrefix)
    }

    companion object {
        fun fromJson(o: JSONObject): CompanyProfile {
            val d = CompanyProfile()
            return CompanyProfile(
                name = o.optString("name", d.name),
                subtitle = o.optString("subtitle", d.subtitle),
                contactLine = o.optString("contactLine", d.contactLine),
                city = o.optString("city", d.city),
                payeeName = o.optString("payeeName", d.payeeName),
                bankAccounts = o.optString("bankAccounts", d.bankAccounts),
                signerName = o.optString("signerName", d.signerName),
                thanks = o.optString("thanks", d.thanks),
                numberPrefix = o.optString("numberPrefix", d.numberPrefix),
            )
        }
    }
}
